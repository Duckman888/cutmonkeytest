/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 330.6316203854474,
        y: 347.9377259035455
      }),
      new Costume("Forest", "./Stage/costumes/Forest.png", { x: 480, y: 360 }),
      new Costume("backdrop2", "./Stage/costumes/backdrop2.svg", {
        x: 277.2669019110279,
        y: 262.96082020914275
      })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "CUT UP MONKEY" },
        this.whenIReceiveCutUpMonkey
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "NOOOOOO" },
        this.whenIReceiveNoooooo
      ),
      new Trigger(Trigger.BROADCAST, { name: "RIP" }, this.whenIReceiveRip)
    ];

    this.vars.lives = -5;
    this.vars.score = 4;

    this.watchers.lives = new Watcher({
      label: "lives",
      style: "normal",
      visible: true,
      value: () => this.vars.lives,
      x: 247,
      y: 164
    });
    this.watchers.score = new Watcher({
      label: "Score",
      style: "normal",
      visible: true,
      value: () => this.vars.score,
      x: 244,
      y: 129
    });
  }

  *whenIReceiveCutUpMonkey() {
    while (!(this.vars.lives < 1)) {
      if (this.vars.score < 50) {
        for (let i = 0; i < 4; i++) {
          this.sprites["Cutmonkey1"].createClone();
          yield;
        }
        yield* this.wait(1);
        this.sprites["Duckduxk"].createClone();
        yield* this.wait(3);
      }
      if (this.vars.score > 50 && this.vars.score < 100) {
        for (let i = 0; i < 5; i++) {
          this.sprites["Cutmonkey1"].createClone();
          yield;
        }
        yield* this.wait(1);
        this.sprites["Duckduxk"].createClone();
        yield* this.wait(3);
      }
      if (this.vars.score > 100) {
        for (let i = 0; i < 4; i++) {
          this.sprites["Cutmonkey1"].createClone();
          yield;
        }
        yield* this.wait(1);
        for (let i = 0; i < 2; i++) {
          this.sprites["Duckduxk"].createClone();
          yield;
        }
        yield* this.wait(3);
      }
      yield;
    }
    this.broadcast("RIP");
  }

  *whenIReceiveNoooooo() {
    this.vars.lives = 0;
  }

  *whenIReceiveRip() {
    this.costume = "backdrop2";
  }
}
