/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Duckduxk extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("DUckDUXk", "./Duckduxk/costumes/DUckDUXk.svg", {
        x: 29.63461538461533,
        y: 26.433926302414193
      }),
      new Costume("DUckDUXk2", "./Duckduxk/costumes/DUckDUXk2.svg", {
        x: 35.50000000000003,
        y: 27
      })
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone)
    ];

    this.vars.myxvelocity2 = -4;
    this.vars.myyvelocity2 = -23;
    this.vars.myrotation = 4;
    this.vars.chopped2 = 0;
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *startAsClone() {
    this.costume = "DUckDUXk";
    this.y = -180;
    this.x = this.random(-240, 240);
    this.direction = 90;
    this.vars.myxvelocity2 = this.random(-5, 5);
    this.vars.myyvelocity2 = this.random(10, 25);
    this.vars.myrotation = this.random(-5, 5);
    this.vars.chopped2 = "False";
    this.visible = true;
    while (!(this.y < -181)) {
      this.direction += this.vars.myrotation;
      this.x += this.vars.myxvelocity2;
      this.y += this.vars.myyvelocity2;
      yield* this.wait(0.05);
      this.vars.myyvelocity2 += -1;
      if (this.touching("mouse") && this.mouse.down) {
        this.vars.chopped2 = "True";
        this.broadcast("NOOOOOO");
        this.costume = "DUckDUXk2";
      }
      yield;
    }
    this.deleteThisClone();
  }
}
